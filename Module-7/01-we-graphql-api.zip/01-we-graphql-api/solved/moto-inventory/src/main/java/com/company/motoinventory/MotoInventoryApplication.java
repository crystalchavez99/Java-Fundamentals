package com.company.motoinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotoInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotoInventoryApplication.class, args);
	}

}
